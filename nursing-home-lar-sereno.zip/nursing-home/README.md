# 🏡 Lar Sereno — Sistema de Gestão para Lar de Idosos

Sistema web Java completo com Spring Boot para gerenciamento de lar de idosos, com autenticação segura e controle de remédios.

---

## 📋 Requisitos

- **Java 17+**
- **Maven 3.8+**

---

## 🚀 Como rodar

### 1. Clone ou extraia o projeto

```bash
cd nursing-home
```

### 2. Compile e rode

```bash
mvn spring-boot:run
```

### 3. Acesse no navegador

```
http://localhost:8080
```

---

## 🔐 Segurança implementada

| Recurso | Descrição |
|---|---|
| **BCrypt (força 12)** | Senhas nunca salvas em texto puro |
| **CSRF Protection** | Token em todas as requisições POST |
| **Session Fixation** | Sessão renovada após login |
| **Session Timeout** | Sessão expira em 30 minutos |
| **Cookie HttpOnly** | JavaScript não acessa o cookie de sessão |
| **SameSite=Strict** | Protege contra CSRF cross-site |
| **Bloqueio de conta** | Conta bloqueada por 15 min após 5 tentativas falhas |
| **Enumeração de usuários** | Mensagem genérica — não revela se email existe |
| **Força de senha** | Exige maiúscula, minúscula e número |
| **Headers de segurança** | CSP, X-Frame-Options, Referrer-Policy |
| **Sessão única** | Um usuário, uma sessão ativa |

---

## 📁 Estrutura do projeto

```
src/main/java/com/lardeidosos/
├── LarDeIdososApplication.java     # Entrada da aplicação
├── config/
│   └── SecurityConfig.java         # Toda a configuração de segurança
├── model/
│   ├── User.java                   # Entidade usuário/cuidador
│   └── Remedio.java                # Entidade remédio
├── repository/
│   ├── UserRepository.java
│   └── RemedioRepository.java
├── service/
│   ├── UserService.java            # Lógica de auth + UserDetailsService
│   └── RemedioService.java         # Lógica de remédios
└── controller/
    ├── AuthController.java         # Login e registro
    ├── DashboardController.java    # Dashboard principal
    └── RemedioController.java      # CRUD de remédios

src/main/resources/
├── application.properties
└── templates/
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── remedios.html
    └── editar-remedio.html
```

---

## 💊 Funcionalidades — Controle de Remédios

- ✅ Cadastrar remédio com nome, dosagem, horário, frequência e residente
- ✅ Marcar remédio como **tomado** / desfazer
- ✅ Atualização automática de status: **Pendente → Atrasado** (30 min após horário)
- ✅ Filtrar por residente
- ✅ Editar e excluir remédios
- ✅ Dashboard com contadores em tempo real

---

## 🗄️ Banco de dados

Usa **H2** (banco embutido) com persistência em arquivo local `./data/lardeidosos`.  
Não precisa instalar nada. Os dados são mantidos entre reinicializações.

Para ver o banco via console web (dev):
```
http://localhost:8080/h2-console
JDBC URL: jdbc:h2:file:./data/lardeidosos
Usuário: admin
Senha: lardeidosos@2024
```

---

## 🏗️ Para produção

Substitua H2 por PostgreSQL ou MySQL no `pom.xml` e `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/lardeidosos
spring.datasource.username=seu_usuario
spring.datasource.password=sua_senha
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

Adicione no `pom.xml`:
```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>
```
