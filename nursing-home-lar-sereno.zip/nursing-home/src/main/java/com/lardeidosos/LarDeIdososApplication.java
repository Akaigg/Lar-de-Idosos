package com.lardeidosos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LarDeIdososApplication {
    public static void main(String[] args) {
        SpringApplication.run(LarDeIdososApplication.class, args);
    }
}
