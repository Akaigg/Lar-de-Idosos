package com.lardeidosos.controller;

import com.lardeidosos.service.UserService;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/dashboard";
    }

    @GetMapping("/login")
    public String loginPage(@RequestParam(required = false) String error,
                            @RequestParam(required = false) String logout,
                            @RequestParam(required = false) String registered,
                            Model model) {
        if (error != null) {
            model.addAttribute("erro", "E-mail ou senha inválidos. Sua conta será bloqueada após 5 tentativas.");
        }
        if (logout != null) {
            model.addAttribute("sucesso", "Sessão encerrada com sucesso.");
        }
        if (registered != null) {
            model.addAttribute("sucesso", "Cadastro realizado! Faça login para continuar.");
        }
        return "login";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String register(
            @RequestParam @NotBlank String nome,
            @RequestParam @Email @NotBlank String email,
            @RequestParam @Size(min = 8) @NotBlank String senha,
            @RequestParam @NotBlank String confirmarSenha,
            RedirectAttributes redirectAttributes) {

        // Validate password confirmation
        if (!senha.equals(confirmarSenha)) {
            redirectAttributes.addFlashAttribute("erro", "As senhas não coincidem.");
            return "redirect:/register";
        }

        // Validate password strength
        if (!senhaForte(senha)) {
            redirectAttributes.addFlashAttribute("erro",
                "A senha deve ter pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas e números.");
            return "redirect:/register";
        }

        try {
            userService.registrar(nome, email, senha);
            return "redirect:/login?registered=true";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
            return "redirect:/register";
        }
    }

    private boolean senhaForte(String senha) {
        if (senha == null || senha.length() < 8) return false;
        boolean temMaiuscula = senha.chars().anyMatch(Character::isUpperCase);
        boolean temMinuscula = senha.chars().anyMatch(Character::isLowerCase);
        boolean temNumero = senha.chars().anyMatch(Character::isDigit);
        return temMaiuscula && temMinuscula && temNumero;
    }
}
