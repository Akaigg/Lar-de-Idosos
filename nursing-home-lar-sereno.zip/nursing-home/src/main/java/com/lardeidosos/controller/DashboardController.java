package com.lardeidosos.controller;

import com.lardeidosos.model.User;
import com.lardeidosos.service.RemedioService;
import com.lardeidosos.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final UserService userService;
    private final RemedioService remedioService;

    public DashboardController(UserService userService, RemedioService remedioService) {
        this.userService = userService;
        this.remedioService = remedioService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User usuario = userService.buscarPorEmail(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        model.addAttribute("usuario", usuario);
        model.addAttribute("totalRemedios", remedioService.contarTotal(usuario));
        model.addAttribute("remediosPendentes", remedioService.contarPendentes(usuario));
        model.addAttribute("remediosTomados", remedioService.contarTomados(usuario));
        model.addAttribute("remediosAtrasados", remedioService.contarAtrasados(usuario));
        model.addAttribute("idosos", remedioService.listarIdosos(usuario));
        model.addAttribute("remediosHoje", remedioService.listarPorUsuario(usuario));

        return "dashboard";
    }
}
