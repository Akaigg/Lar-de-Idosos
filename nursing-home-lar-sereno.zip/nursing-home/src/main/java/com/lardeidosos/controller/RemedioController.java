package com.lardeidosos.controller;

import com.lardeidosos.model.Remedio;
import com.lardeidosos.model.User;
import com.lardeidosos.service.RemedioService;
import com.lardeidosos.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalTime;

@Controller
@RequestMapping("/remedios")
public class RemedioController {

    private final RemedioService remedioService;
    private final UserService userService;

    public RemedioController(RemedioService remedioService, UserService userService) {
        this.remedioService = remedioService;
        this.userService = userService;
    }

    @GetMapping
    public String listar(@AuthenticationPrincipal UserDetails userDetails,
                         @RequestParam(required = false) String idoso,
                         Model model) {
        User usuario = getUsuario(userDetails);

        var remedios = (idoso != null && !idoso.isBlank())
            ? remedioService.listarPorIdoso(usuario, idoso)
            : remedioService.listarPorUsuario(usuario);

        model.addAttribute("usuario", usuario);
        model.addAttribute("remedios", remedios);
        model.addAttribute("idosos", remedioService.listarIdosos(usuario));
        model.addAttribute("filtroIdoso", idoso);
        model.addAttribute("novoRemedio", new Remedio());
        model.addAttribute("pendentes", remedioService.contarPendentes(usuario));
        model.addAttribute("tomados", remedioService.contarTomados(usuario));
        model.addAttribute("atrasados", remedioService.contarAtrasados(usuario));

        return "remedios";
    }

    @PostMapping("/adicionar")
    public String adicionar(@AuthenticationPrincipal UserDetails userDetails,
                            @RequestParam String nome,
                            @RequestParam String dosagem,
                            @RequestParam String horario,
                            @RequestParam String frequencia,
                            @RequestParam String idosoNome,
                            @RequestParam(required = false) String observacoes,
                            RedirectAttributes redirectAttributes) {
        User usuario = getUsuario(userDetails);

        try {
            Remedio remedio = new Remedio();
            remedio.setNome(nome);
            remedio.setDosagem(dosagem);
            remedio.setHorario(LocalTime.parse(horario));
            remedio.setFrequencia(frequencia);
            remedio.setIdosoNome(idosoNome);
            remedio.setObservacoes(observacoes);

            remedioService.salvar(remedio, usuario);
            redirectAttributes.addFlashAttribute("sucesso", "Remédio cadastrado com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao cadastrar remédio: " + e.getMessage());
        }

        return "redirect:/remedios";
    }

    @PostMapping("/{id}/tomar")
    public String marcarTomado(@AuthenticationPrincipal UserDetails userDetails,
                                @PathVariable Long id,
                                RedirectAttributes redirectAttributes) {
        User usuario = getUsuario(userDetails);
        try {
            remedioService.marcarComoTomado(id, usuario);
            redirectAttributes.addFlashAttribute("sucesso", "Remédio marcado como tomado!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao atualizar remédio.");
        }
        return "redirect:/remedios";
    }

    @PostMapping("/{id}/destomar")
    public String desmarcarTomado(@AuthenticationPrincipal UserDetails userDetails,
                                   @PathVariable Long id,
                                   RedirectAttributes redirectAttributes) {
        User usuario = getUsuario(userDetails);
        try {
            remedioService.desmarcarTomado(id, usuario);
            redirectAttributes.addFlashAttribute("sucesso", "Status do remédio atualizado.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao atualizar remédio.");
        }
        return "redirect:/remedios";
    }

    @PostMapping("/{id}/deletar")
    public String deletar(@AuthenticationPrincipal UserDetails userDetails,
                           @PathVariable Long id,
                           RedirectAttributes redirectAttributes) {
        User usuario = getUsuario(userDetails);
        try {
            remedioService.deletar(id, usuario);
            redirectAttributes.addFlashAttribute("sucesso", "Remédio removido com sucesso.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao remover remédio.");
        }
        return "redirect:/remedios";
    }

    @GetMapping("/{id}/editar")
    public String editarForm(@AuthenticationPrincipal UserDetails userDetails,
                              @PathVariable Long id,
                              Model model) {
        User usuario = getUsuario(userDetails);
        Remedio remedio = remedioService.buscarPorId(id, usuario)
            .orElseThrow(() -> new RuntimeException("Remédio não encontrado"));

        model.addAttribute("usuario", usuario);
        model.addAttribute("remedio", remedio);
        model.addAttribute("idosos", remedioService.listarIdosos(usuario));
        return "editar-remedio";
    }

    @PostMapping("/{id}/editar")
    public String editar(@AuthenticationPrincipal UserDetails userDetails,
                          @PathVariable Long id,
                          @RequestParam String nome,
                          @RequestParam String dosagem,
                          @RequestParam String horario,
                          @RequestParam String frequencia,
                          @RequestParam String idosoNome,
                          @RequestParam(required = false) String observacoes,
                          RedirectAttributes redirectAttributes) {
        User usuario = getUsuario(userDetails);
        try {
            Remedio dados = new Remedio();
            dados.setNome(nome);
            dados.setDosagem(dosagem);
            dados.setHorario(LocalTime.parse(horario));
            dados.setFrequencia(frequencia);
            dados.setIdosoNome(idosoNome);
            dados.setObservacoes(observacoes);

            remedioService.atualizar(id, dados, usuario);
            redirectAttributes.addFlashAttribute("sucesso", "Remédio atualizado com sucesso!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("erro", "Erro ao atualizar remédio.");
        }
        return "redirect:/remedios";
    }

    private User getUsuario(UserDetails userDetails) {
        return userService.buscarPorEmail(userDetails.getUsername())
            .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
    }
}
