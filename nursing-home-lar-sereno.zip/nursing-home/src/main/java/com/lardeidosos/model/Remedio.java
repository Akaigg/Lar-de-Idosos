package com.lardeidosos.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "remedios")
public class Remedio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nome do remédio é obrigatório")
    @Column(nullable = false)
    private String nome;

    @NotBlank(message = "Dosagem é obrigatória")
    @Column(nullable = false)
    private String dosagem;

    @NotNull(message = "Horário é obrigatório")
    @Column(nullable = false)
    private LocalTime horario;

    @Column(length = 500)
    private String observacoes;

    @NotBlank(message = "Frequência é obrigatória")
    @Column(nullable = false)
    private String frequencia; // Diário, 2x ao dia, etc.

    @Column(nullable = false)
    private String idosoNome; // Nome do idoso associado

    @Column(nullable = false)
    private boolean tomado = false;

    private LocalDateTime tomadoEm;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusRemedio status = StatusRemedio.PENDENTE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private User usuario;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime criadoEm;

    public enum StatusRemedio {
        PENDENTE, TOMADO, ATRASADO, CANCELADO
    }

    // Constructors
    public Remedio() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDosagem() { return dosagem; }
    public void setDosagem(String dosagem) { this.dosagem = dosagem; }

    public LocalTime getHorario() { return horario; }
    public void setHorario(LocalTime horario) { this.horario = horario; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    public String getFrequencia() { return frequencia; }
    public void setFrequencia(String frequencia) { this.frequencia = frequencia; }

    public String getIdosoNome() { return idosoNome; }
    public void setIdosoNome(String idosoNome) { this.idosoNome = idosoNome; }

    public boolean isTomado() { return tomado; }
    public void setTomado(boolean tomado) { this.tomado = tomado; }

    public LocalDateTime getTomadoEm() { return tomadoEm; }
    public void setTomadoEm(LocalDateTime tomadoEm) { this.tomadoEm = tomadoEm; }

    public StatusRemedio getStatus() { return status; }
    public void setStatus(StatusRemedio status) { this.status = status; }

    public User getUsuario() { return usuario; }
    public void setUsuario(User usuario) { this.usuario = usuario; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
}
