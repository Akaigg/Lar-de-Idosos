package com.lardeidosos.repository;

import com.lardeidosos.model.Remedio;
import com.lardeidosos.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RemedioRepository extends JpaRepository<Remedio, Long> {

    List<Remedio> findByUsuarioOrderByHorarioAsc(User usuario);

    List<Remedio> findByUsuarioAndIdosoNomeOrderByHorarioAsc(User usuario, String idosoNome);

    List<Remedio> findByUsuarioAndStatusOrderByHorarioAsc(User usuario, Remedio.StatusRemedio status);

    @Query("SELECT DISTINCT r.idosoNome FROM Remedio r WHERE r.usuario = :usuario ORDER BY r.idosoNome")
    List<String> findDistinctIdososByUsuario(User usuario);

    long countByUsuarioAndStatus(User usuario, Remedio.StatusRemedio status);

    long countByUsuario(User usuario);
}
