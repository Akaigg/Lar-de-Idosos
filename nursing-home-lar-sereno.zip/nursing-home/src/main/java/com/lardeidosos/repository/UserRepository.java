package com.lardeidosos.repository;

import com.lardeidosos.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    @Modifying
    @Query("UPDATE User u SET u.tentativasLogin = u.tentativasLogin + 1 WHERE u.email = :email")
    void incrementarTentativas(String email);

    @Modifying
    @Query("UPDATE User u SET u.tentativasLogin = 0, u.bloqueadoAte = null WHERE u.email = :email")
    void resetarTentativas(String email);
}
