package com.lardeidosos.service;

import com.lardeidosos.model.Remedio;
import com.lardeidosos.model.User;
import com.lardeidosos.repository.RemedioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RemedioService {

    private final RemedioRepository remedioRepository;

    public RemedioService(RemedioRepository remedioRepository) {
        this.remedioRepository = remedioRepository;
    }

    public Remedio salvar(Remedio remedio, User usuario) {
        remedio.setUsuario(usuario);
        remedio.setStatus(Remedio.StatusRemedio.PENDENTE);
        return remedioRepository.save(remedio);
    }

    public List<Remedio> listarPorUsuario(User usuario) {
        List<Remedio> remedios = remedioRepository.findByUsuarioOrderByHorarioAsc(usuario);
        // Atualizar status automaticamente
        remedios.forEach(this::atualizarStatusAutomatico);
        return remedioRepository.findByUsuarioOrderByHorarioAsc(usuario);
    }

    public List<Remedio> listarPorIdoso(User usuario, String idosoNome) {
        return remedioRepository.findByUsuarioAndIdosoNomeOrderByHorarioAsc(usuario, idosoNome);
    }

    public List<String> listarIdosos(User usuario) {
        return remedioRepository.findDistinctIdososByUsuario(usuario);
    }

    public Optional<Remedio> buscarPorId(Long id, User usuario) {
        return remedioRepository.findById(id)
            .filter(r -> r.getUsuario().getId().equals(usuario.getId()));
    }

    public Remedio marcarComoTomado(Long id, User usuario) {
        Remedio remedio = buscarPorId(id, usuario)
            .orElseThrow(() -> new RuntimeException("Remédio não encontrado"));

        remedio.setTomado(true);
        remedio.setTomadoEm(LocalDateTime.now());
        remedio.setStatus(Remedio.StatusRemedio.TOMADO);
        return remedioRepository.save(remedio);
    }

    public Remedio desmarcarTomado(Long id, User usuario) {
        Remedio remedio = buscarPorId(id, usuario)
            .orElseThrow(() -> new RuntimeException("Remédio não encontrado"));

        remedio.setTomado(false);
        remedio.setTomadoEm(null);
        remedio.setStatus(Remedio.StatusRemedio.PENDENTE);
        return remedioRepository.save(remedio);
    }

    public void deletar(Long id, User usuario) {
        Remedio remedio = buscarPorId(id, usuario)
            .orElseThrow(() -> new RuntimeException("Remédio não encontrado"));
        remedioRepository.delete(remedio);
    }

    public Remedio atualizar(Long id, Remedio dadosAtualizados, User usuario) {
        Remedio remedio = buscarPorId(id, usuario)
            .orElseThrow(() -> new RuntimeException("Remédio não encontrado"));

        remedio.setNome(dadosAtualizados.getNome());
        remedio.setDosagem(dadosAtualizados.getDosagem());
        remedio.setHorario(dadosAtualizados.getHorario());
        remedio.setFrequencia(dadosAtualizados.getFrequencia());
        remedio.setIdosoNome(dadosAtualizados.getIdosoNome());
        remedio.setObservacoes(dadosAtualizados.getObservacoes());

        return remedioRepository.save(remedio);
    }

    // Stats for dashboard
    public long contarPendentes(User usuario) {
        return remedioRepository.countByUsuarioAndStatus(usuario, Remedio.StatusRemedio.PENDENTE);
    }

    public long contarTomados(User usuario) {
        return remedioRepository.countByUsuarioAndStatus(usuario, Remedio.StatusRemedio.TOMADO);
    }

    public long contarAtrasados(User usuario) {
        return remedioRepository.countByUsuarioAndStatus(usuario, Remedio.StatusRemedio.ATRASADO);
    }

    public long contarTotal(User usuario) {
        return remedioRepository.countByUsuario(usuario);
    }

    private void atualizarStatusAutomatico(Remedio remedio) {
        if (remedio.isTomado()) return;
        LocalTime agora = LocalTime.now();
        LocalTime horario = remedio.getHorario();
        // Mark as late if more than 30 minutes past scheduled time
        if (agora.isAfter(horario.plusMinutes(30))) {
            remedio.setStatus(Remedio.StatusRemedio.ATRASADO);
            remedioRepository.save(remedio);
        }
    }
}
