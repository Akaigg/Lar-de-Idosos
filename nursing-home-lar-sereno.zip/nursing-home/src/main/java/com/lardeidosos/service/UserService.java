package com.lardeidosos.service;

import com.lardeidosos.model.User;
import com.lardeidosos.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;

@Service
@Transactional
public class UserService implements UserDetailsService {

    private static final int MAX_TENTATIVAS = 5;
    private static final int MINUTOS_BLOQUEIO = 15;

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));

        // Check if account is locked
        if (user.isContaBloqueada()) {
            throw new LockedException("Conta bloqueada temporariamente. Tente novamente em " + MINUTOS_BLOQUEIO + " minutos.");
        }

        if (!user.isAtivo()) {
            throw new DisabledException("Conta desativada.");
        }

        return new org.springframework.security.core.userdetails.User(
            user.getEmail(),
            user.getSenha(),
            user.isAtivo(),
            true,
            true,
            !user.isContaBloqueada(),
            Collections.singletonList(new SimpleGrantedAuthority(user.getRole()))
        );
    }

    public User registrar(String nome, String email, String senha) {
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("E-mail já cadastrado.");
        }

        User user = new User();
        user.setNome(nome);
        user.setEmail(email.toLowerCase().trim());
        // BCrypt hash with strength 12
        user.setSenha(passwordEncoder.encode(senha));
        user.setRole("ROLE_USER");
        user.setAtivo(true);

        return userRepository.save(user);
    }

    public void registrarLoginSucesso(String email) {
        userRepository.findByEmail(email).ifPresent(user -> {
            user.setTentativasLogin(0);
            user.setBloqueadoAte(null);
            userRepository.save(user);
        });
    }

    public void registrarLoginFalha(String email) {
        userRepository.findByEmail(email).ifPresent(user -> {
            int tentativas = user.getTentativasLogin() + 1;
            user.setTentativasLogin(tentativas);

            if (tentativas >= MAX_TENTATIVAS) {
                user.setBloqueadoAte(LocalDateTime.now().plusMinutes(MINUTOS_BLOQUEIO));
                user.setTentativasLogin(0);
            }

            userRepository.save(user);
        });
    }

    public Optional<User> buscarPorEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean emailJaCadastrado(String email) {
        return userRepository.existsByEmail(email);
    }

    // Custom exceptions
    public static class LockedException extends RuntimeException {
        public LockedException(String message) { super(message); }
    }

    public static class DisabledException extends RuntimeException {
        public DisabledException(String message) { super(message); }
    }
}
